﻿'use strict';
var chalk = require('chalk');

class cLog {
    constructor() { }
    log(...args) {
        var r = '* ';
        var style;
        for (let a of args) {
            if (a.toString().indexOf('$') != -1) {
                style = /\$(.*)/gm.exec(a);
                style = style[1];
                try {
                    r += chalk[style](args[args.indexOf(a) + 1]) + ' ';
                    args.splice(args[args.indexOf(a)], 1);
                }
                catch{
                    r += `${a} `;
                }

            }
            else if (typeof style != "undefined") {
                try {
                    r += chalk[style](args[args.indexOf(a)]) + ' ';
                }
                catch{
                    r += `${a} `;
                }
            }
            else {
                r += `${a} `;
            }
        }
        console.log(chalk[`white`](r));
    }
}
let c = new cLog();
module.exports = c.log; 
