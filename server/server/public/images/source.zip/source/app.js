/// <reference path="colorlog.js" />
'use strict';
/**
 * IMPORTS
 * */
const xlsx = require('xlsx-populate');
const addressConverter = require("/node_modules/xlsx-populate/lib/addressConverter.js");
const fs = require('fs-extra');
const util = require("util");
const stringSimilarity = require('string-similarity');
const log = require('./colorlog.js');
const questions = require('./questions.js');
const diff = require('date-diff');
const open = require('open');


class BillCompare {

    /**
     * Pauses script execution.
     * @param {number} the amount of time (in ms) to pause. 
     */
    pause(ms) {
        return new Promise(resolve => setTimeout(resolve, 0));
    }

    /**
     * Opens the spreadsheets provided, with the option to provide multiple paths at once.
     * @param {String | Array} a string, or an array of strings representing file paths.  
     * @async  
     */
    async openXLSX(path) {
        let ret = {};
        let i = this == undefined ? -1 : this.openedData.length - 1;
        let name;
        

        if (Array.isArray(path)) {
            for (let p of path) {
                ret = {};
                name = p.substring(p.lastIndexOf('/') + 1);
                let d = await fs.readFile(p);
                let wb = await xlsx.fromDataAsync(d, null);
                i++;
                ret['id'] = i;
                ret['wb'] = wb;
                ret['name'] = name;
                this.openedData.push(ret);
            }
            return this.openedData;
        }
        else if (typeof path == "string") {
            name = path.substring(path.lastIndexOf('/') + 1);
            let d = await fs.readFile(path);
            let wb = await xlsx.fromDataAsync(d, null);
            ret['id'] = i;
            ret['wb'] = wb;
            ret['name'] = name;
            this.openedData.push(ret);
            return ret;
        }
    }
   
    /**
     * Gets cells in the ranges provided in the column mappings.  
     * @param {any} wb An XLSX-Populate workbook object.
     * @param {any} mapping An object representing column mappings.  Check the constructor for examples.  
     */
    async getCellRanges(wb, mapping) {
        let r = {};
        let ret = [];

        //Convert mapping keys to upper case.
        for (let k of Object.keys(mapping)) {
            mapping[k] = mapping[k].toUpperCase();
        }

        if (typeof mapping == "object") {
            log('$yellow','Pulling data from a sheet... ')
            for (let key of Object.keys(mapping)) {
                let letter = mapping[key];
                let rows = wb.sheet(0).usedRange()._numRows;
                let range = wb.sheet(0).range(letter + this.RANGE_OFFSET + ':' + letter + rows);

                r[key] = { 'range': range, 'rows': rows };

                log("$green", `Pulled data in range`,`$red`,` ${letter + this.RANGE_OFFSET + ' : ' + letter + rows}`, "$green", `- ${key}`);
                await this.pause(600); 
            }
            console.log(`\n`);
            return r;
        }
        log.red("Mapping must be an object of excel columns!");
    }

    /**
     * Removes the additional array layer that XLSX-Populate adds to cells in its ranges.  
     * @param {any} data an XLSX-Populate range object.  
     */
    exposeCells(data) {
        let cells;
        let exposedRanges = {}; 
        for (let k of Object.keys(data)) {
            let r = [];
            let range = data[k].range; 
            cells = range.cells();
            let exCells = cells.forEach(cell => { r.push(cell[0]); });
            exposedRanges[k] = r; 
        }
        return exposedRanges;
    }

    /**
     * Gets the column mappings for the provided fields in cols.  
     * @param {Array} cols an array of columns to consider. 
     * @param {String} status the name of the sheet columns are being queried for.
     * @async
     */
    async setColumns(cols, status) {
        let r = {};

        if (!Array.isArray(cols)) {
            log("$red", "Cols must be an array!");
            return; 
        }

        for (let c of cols) {
            let q = await questions.str(`Please provide the column name for ${c} in ${status}`);
            r[c] = q; 
        }
        console.log('\n');
        return r; 
    }

    /**
     * Combines other internal functions to make the data easily usable by this program.  
     * @param {Array} data an array of file paths from INPUT_FOLDER.  
     */
    async prepData(data) {
        let r = {}; 

        log('$cyan', `${data.length} file(s) detected in ${this.INPUT_FOLDER}`);

        if (data.length !== 2) {
            log('$red', 'This script can only compare two scripts at a time.  Exiting!'); 
            process.exit(); 
        }

        //Print the file names. 
        for (let d of data) {
            log("$green", `(${data.indexOf(d)}) ${d.name}`);
        }

        //Prompt the user to specify the older of the two files.  
        this.oldPrompt = await questions.int('Please provide the number of the older file');
        for (let d of data) {
            if (d.id == this.oldPrompt) {
                r['old'] = d;
            }
            else {
                r['new'] = d; 
            }
        }

        //Present the default column mappings.  
        log(`$bold`, 'DEFAULT MAPPINGS:\n');
        log("$green", "OLD:");
        log("$yellow", util.inspect(this.OLD_DEFAULTS));
        log("$green", "NEW:");
        log("$yellow", util.inspect(this.NEW_DEFAULTS));

        let mapping = await questions.boolean('Use the default mappings for column names?');

        //Let the user specify them if needed.  
        if (!mapping) {
            let oldMap = await this.setColumns(['shipToNum', 'billToNum', 'repCol', 'subStatus', 'billed', 'startDate', 'endDate', 'orderDate', 'libName', 'libState'], r['old'].name);
            let newMap = await this.setColumns(['shipToNum', 'billToNum', 'repCol', 'subStatus', 'billed', 'startDate', 'endDate', 'orderDate', 'libName', 'libState'], r['new'].name);
            r['old'].map = oldMap;
            r['new'].map = newMap;
        }
        else {
            r['old'].map = this.OLD_DEFAULTS;
            r['new'].map = this.NEW_DEFAULTS;
        }

        let oldRanges = await this.getCellRanges(r['old'].wb, r['old'].map); 
        let newRanges = await this.getCellRanges(r['new'].wb, r['new'].map); 

        r['old'].ranges = this.exposeCells(oldRanges);
        r['new'].ranges = this.exposeCells(newRanges);

        return r; 
    }

    /**
     * Extract the sheet data into a human-readable format.
     * This does make some efforts to normalize the data.
     * @param {any} data
     */
    getData(data) {
        let ret = []; 
        let skipped = []; 
        let cellKeys = Object.keys(data.ranges); 

        for (let n of data.ranges.libName) {
            let r = {};
            let cell; 
            for (let k of cellKeys) {
                switch (k) {
                    case 'libName':
                        let LibName = n.value();
                        cell = data.ranges[k][data.ranges.libName.indexOf(n)];
                        let sCell = data.ranges['libState'][data.ranges.libName.indexOf(n)];
                        if (LibName != undefined) {
                            let ID = `${LibName.toUpperCase()} - ${sCell.value().toUpperCase()}`;
                            if (LibName.toLowerCase().indexOf('bill') == -1 || LibName.toLowerCase().indexOf('billings') != -1) {
                                r['id'] = ID;
                                r['cell'] = cell.address();
                            }
                            else {
                                console.log(`* No id was found for ${n.value()}`);
                                r['cell'] = cell;
                                skipped.push(r);
                            }

                        }
                        break;
                    case 'libState':
                        break;
                    case 'repCol':
                        cell = data.ranges[k][data.ranges.libName.indexOf(n)];
                        let name = /(.*),(.*)/g.exec(cell.value());

                        if (name != null) {
                            r[k] = `${name[2].toUpperCase()} ${name[1].toUpperCase()}`.trim();
                        }

                        else {
                            r[k] = cell.value();
                        }
                        r['cell'] = cell.address();
                        break;
                    default:
                        cell = data.ranges[k][data.ranges.libName.indexOf(n)];
                        r[k] = cell.value();
                        r['cell'] = cell.address();
                        //Handler for blank billToNums 
                        if (k == 'billToNum' && r[k] == undefined) {
                            r[k] = r['shipToNum'];
                        }
                        break;
                }
            }
            ret.push(r); 
        }
        ret = ret.sort((a, b) => (a.id > b.id) ? 1 : -1);
        ret.pop();
        return ret;
    }

    /**
     * Adds spreadsheet changes to the changes array.  
     * @param {string} cell - a cell address.
     * @param {string} type - the type of change to make.
     * @param {any} old - (optional) old data.
     * @param {any} n - (optional) new data.  
     */
    addChange(cell, type, old,n ) {
        let r = { c: cell, t: type };

        if (typeof old != "undefined") {
            r['o'] = old;
        }

        if (typeof n != "undefined") {
            r['n'] = n; 
        }
        this.changes.push(r); 
    }
    async commit() {
        let newNumber = this.getNewSheet();
        let newWB = this.input_files[newNumber];
        let wb2 = this.prepped_files;



        //Copy the new version of the sheet to generate the report.
        await fs.copy(`\input\\${newWB.name}`, `.\\output\\${newWB.name}`);
        log("$yellow",'Made a copy of the new workbook.')


        //Open the copy as a workbook via xlsx-populate.  
        this.output = await this.openXLSX(`.\\output\\${newWB.name}`);


        log("$yellow", 'Pushing changes...')
        for (let c of this.changes) {
            let changeKeys = Object.keys(c);
            let cell = this.output.wb.sheets()[0].cell(c.c);


            

            if (c.t != 'skipped') {
                let cellRow = wb2.new.map[c.t];
                let address = `${cellRow}${cell.rowNumber()}`;
                cell = this.output.wb.sheets()[0].cell(address);
            }
            else {
                let rowNo = cell.row().rowNumber();
                let minCol = addressConverter.columnNumberToName(this.output.wb.sheet(0).usedRange()._minColumnNumber);
                let maxCol = addressConverter.columnNumberToName(this.output.wb.sheet(0).usedRange()._maxColumnNumber);
                var row = this.output.wb.sheet(0).range(minCol + rowNo + ":" + maxCol + rowNo);
            }

            

            switch (c.t) {
                case 'skipped':
                    row.style('fill', this.errorColors[c.t]);
                    break;
                default:
                    cell.style('fill', this.errorColors[c.t]);
            }

           

            //console.log(output.sheet.cell(c.cell).value("TEST"))
            for (let change of changeKeys) {
                
            }
        }
        //Add the legend.
        log("$yellow", 'Making workbook...')
        this.addAuditLegend();



        //Save the output sheet.  
        await this.output.wb.toFileAsync(`.\\output\\${newWB.name}`);
        let newPath = `.\\output\\${newWB.name}`;
        log('$yellow','Done! Opening output file now...')

        open(newPath, {wait:true}).then(function () {
            process.exit(); 
        }); 
        
        
    }
  
    async go(data) {
        this.input_files = await this.openXLSX(data); 
        this.prepped_files = await this.prepData(this.input_files);

        let newData = this.prepped_files.new; 
        let oldData = this.prepped_files.old; 

        let dates = []; 

        //Exit with a notice if the new sheet contains multiple months of data.
        //TODO:  Let the user specify the date. 
        for (let d of newData.ranges.orderDate) {
            let date = xlsx.numberToDate(d.value());
            let month = date.toLocaleString('en-us', { month: 'long' });
            let day = date.toLocaleString('en-us', { day: '2-digit' });
            let year = date.toLocaleString('en-us', { year: '2-digit' });

            let r = { D: d.value(), m: month, d: day, y: year, c: d };

            if (month == "Invalid Date") {
                log("$red", "INVALID DATE found in orderDate column!");
                process.exit();
            }

            else {
                if (dates.length > 0 && dates[dates.length - 1] != null) {
                    let oldDate = dates[dates.length - 1];
                    if (oldDate.m != r.m) {
                        log('$red', 'Multiple months of data were found in the new spreadsheet!');
                        process.exit(); 
                    }
                }
                dates.push(r); 
            }
        }

        newData = this.getData(newData);
        oldData = this.getData(oldData); 


        let matches = [];
        let missed = [];
        let newlibs = [];
        //TODO:  Make sure this pulls form getData's skipped variable. 
        let skipped = []; 


        log(`$yellow`, `Searching for matches...`);
        this.pause(600); 

        for (let n of newData) {
            let newID = n.id; 
            let pushedData = false; 

            //First matching pass -- simply check IDs.  
            for (let o of oldData) {
                if (o.id == n.id) {
                    log("$cyan", `Found matching data for `, `$green`, `${n.id}`);
                    await this.pause(600);
                    matches.push({ old: o, new: n });
                    pushedData = true; 
                }
            }

            //If no matches were found, check first to see if the account is new.  
            if (pushedData == false) {
                if (n.subStatus.toLowerCase() == 'new') {
                    newlibs.push(n);
                    log("$green", `${n.id}`, `$cyan`, `appears to be a new account!`);
                    await this.pause(600);
                }
                else {
                    log("$cyan", `No matching data for `,`$green`,`${n.id}`);
                    missed.push(n); 
                    await this.pause(600);
                }
            }
        }
        await this.pause(800);
        log("$yellow", "MATCHING RESULTS");
        await this.pause(600);

        //Provide a report of results. 
        let max = (newData.length - 1) + (newlibs.length - 1) ;
        console.log('\n----------');
        await this.pause(400);
        log('$green', `${matches.length}/${max}`,'$cyan', "libraries were matched with older data.");
        await this.pause(400);
        log('$green', `${missed.length}/${max}`, '$cyan', "libraries were not matched with older data");
        await this.pause(400);
        log("$green", `${skipped.length}/${max}`, '$cyan', "libraries were skipped due to errors.");
        await this.pause(400);
        log("$green", `${newlibs.length}/${max}`, '$cyan', "libraries were listed as new.");
        await this.pause(600);
        console.log('----------\n');
        await this.pause(600);

        log('$yellow', 'Attempting to match missing data to accounts from the old sheet...');
        await this.pause(600);

        let oldStrings = []; 
        let oldD = [];
        for (let ol of oldData) {
            if (ol.id != undefined) {
                oldStrings.push(ol.id);
                oldD.push(ol);
            }
        }

        //Don't tell anyone...
        let remainingMissed = JSON.parse(JSON.stringify(missed));
        let found = [];
        for (let m of remainingMissed) {
            let q = null;
            let bestMatch = stringSimilarity.findBestMatch(m.id, oldStrings);
            log('$cyan','Is',"$green",`${m.id}`, "$cyan", "the same account as", "$green", `${bestMatch.bestMatch.target}?`);
            q = await questions.boolean(' '); 

            if (q) {
                let oldDatum = oldD[oldStrings.indexOf(bestMatch.bestMatch.target)];
                log("$yellow", `Added matched data for `, `$green`, `${m.id}`);
                matches.push({ old: oldDatum, new: m });
                found.push(m);
                await this.pause(400);
            }
            else { }
        }
        missed = []; 
        for (let r of remainingMissed) {
            if (found.indexOf(r) == -1) {
                missed.push(r); 
            }
        }

        await this.pause(600);

        //At this point, if a match hasn't been found the account may be billed as a renewal in error -- might need to add a handler later.
        //TODO:  Let the user provide the specifc cell? Flag as an error? 
        console.log('\n');
        log('$yellow',`${missed.length} account(s) could not be matched:`);
        for (let m of missed) {
            log('$cyan', `  ${m.id}`, m.cell);
            await this.pause(300); 
        }
        log('$yellow', "This may be due to an account improperly being lableed as a renewal.");
        await this.pause(800);
        log('$yellow', "They will be skipped by this program and labled in the output file.");
        await this.pause(800);

        let c = await questions.boolean("Continue?");

        if (!c) {
            process.exit(); 
        }

        console.log('\n');
        for (let m of matches) {
            await this.pause(400);
            let change = {};
            log('$bold', `Validating ${m.new.id} ...`);
            await this.pause(400);
            let old_subStatus = m.old.subStatus.toLowerCase();
            let new_subStatus = m.new.subStatus.toLowerCase(); 

            if (new_subStatus == "renewal") {
                let old_endDate = m.old.endDate;
                let new_startDate = m.new.startDate;
                log('$cyan',`   Checking the range between the old end date and the new start date...`);
                await this.pause(400);
              
                let dDiff = new_startDate - old_endDate; 

                if (Math.abs(dDiff) != 1) {
                    log('   An incorrect start date has been detected!');
                    this.addChange(m.new.cell, "startDate");
                    await this.pause(200);
                }
            }

            log('$cyan','   validating subscription status...');
            await this.pause(400);

            //If the subStatus is incorrect for the new sheet.  
            if (old_subStatus == "new" && new_subStatus != "renewal") {
                log('   the account has not been made a renewal in the new one!');
                this.addChange(m.new.cell, "subStatus");
                await this.pause(200);
            }

            log('$cyan','   validating sales rep field...');
            await this.pause(400);
            if (m.old.repCol != m.new.repCol) {
                log(`        Difference in reps found! old: ${m.old.repCol}, new: ${m.new.repCol}`);
                this.addChange(m.new.cell, "repCol", m.old.repCol, m.new.repCol);
                await this.pause(200);
            }

            log('$cyan','   validating amount billed...');
            await this.pause(400);
            if (m.old.billed != m.new.billed) {
                log(`        Difference in billed amount found! old: ${m.old.billed}, new: ${m.new.billed}`);
                this.addChange(m.new.cell, "billed", m.old.billed, m.new.billed);
                await this.pause(200);

            }
            
            log('$cyan','   validating shipTo/billTo numbers...');
            await this.pause(400);
            //NOTE:  I don't remmeber validating these numbers, like ever.  
            //The data behaves for right now but we might need to revisit.  
            if (m.old.billToNum != m.new.billToNum) {
                log(`        Billed to Number changed from its old value: ${m.old.billToNum}, new: ${m.new.billToNum}`);
                this.addChange(m.new.cell, "billToNum", m.old.billToNum, m.new.billToNum);
                await this.pause(200);
            }

            if (m.old.shipToNum != m.new.shipToNum) {
                log(`        Ship to Number changed from its old value: ${m.old.shipToNum}, new: ${m.new.shipToNum}`);
                this.addChange(m.new.cell, "shipToNum", m.old.shipToNum, m.new.shipToNum);
                await this.pause(200);
            }
        }

        //Add changes for skipped rows.
        for (let s of skipped) {
            this.addChange(s.cell, "skipped");
        }

        //Add changes for missed rows. 
        for (let m of missed) {
            this.addChange(m.cell, "skipped");
        }

        //Commit changes.
        log('$yellow', "committing changes to output file..."); 
        let save = this.commit();



    }
  
    constructor(data) {
        /**
         * CONFIGURATION
         * */

        /* USER-DEFINABLE VARAIBLES */
        this.OUTPUT_FOLDER = 'output/'; // The output folder.  This program outputs an 'audited' copy of the new sheet.  
        this.INPUT_FOLDER = 'input/'; // The folder to look in for the input files. Should only ever have two!
        this.RANGE_OFFSET = 3; // All columns are offset by this amount -- meant to avoid heading names/blank space in the data.  

        //Default column mappings for the old and new sheets in INPUT_FOLDER.  
        //If the data permenantly changes from these mappings, update them to point to the correct columns.  
        //The program will allow you to manually specify them each time -- but that will get tedious fast!

        this.OLD_DEFAULTS = {
            'shipToNum': 'I',
            'billToNum': 'L',
            'repCol': 'T',
            'subStatus': 'U',
            'billed': 'Y',
            'startDate': 'AE',
            'endDate': 'AF',
            'orderDate': 'G',
            'libName': 'J',
            'libState': 'K',
        }
        this.NEW_DEFAULTS = {
            'shipToNum': 'L',
            'billToNum': 'I',
            'repCol': 'AT',
            'subStatus': 'AU',
            'billed': 'Z',
            'startDate': 'AR',
            'endDate': 'AS',
            'orderDate': 'C',
            'libName': 'J',
            'libState': 'K'
        }

        /* VARIABLES RELATED TO THE ADUIT LOG */
        this.action = {
            review: `Please review the affected cells and determine whether the change is intentional.`,
            subStatus: `Please set the affected cells to a Renewal status`, 
            startDate: `Please check that the start date on the new sheet lines up with the end date on the old sheet.`,
            manual: `Please compare the data for the affected rows manually.`
        }
        this.auditLegend = {
            shipToNum: 'Indicates that the Ship To number from the old sheet is not the same as the one listed in the new sheet.',
            shipToNum_action: this.action.review,
            billToNum: 'Indicates that the Bill To number from the old sheet is not the same as the one listed in the new sheet.',
            billToNum: this.action.review,
            repCol: 'Indicates that the Sales Rep field has changed from the old sheet to the new one.',
            repCol_action: this.action.review,
            subStatus: 'Indicates that the Account was a new account in the old sheet, and should be a renwal now.',
            subStatus_action: this.action.subStatus,
            billed: 'Indicates that the Amount Billed is not the same as the one listed in the new sheet. ',
            billed_action: this.action.review,
            startDate: 'Indicates that the Start Date on the new sheet is incorect based on the timeframe provided in the old sheet.',
            startDate_action: this.action.startDate, 
            skipped: 'Indicates that the row was skipped -- usually because a matching row in the old sheet couldn\'t be found.',
            skipped_action: this.action.manual 
        }

        this.errorColors = {
            skipped: 'f2fff9e',
            shipToNum: '9efff5',
            billToNum: '9efff5',
            billed: 'ffa159',
            repCol: 'ff5959',
            subStatus: 'e2a8ff',
            startDate: 'e3aaff'
        }
        this.self = this; 

        /* SYSTEM (DO NOT MODIFY) */
        this.changes = [];
        this.openedData = [];

        //CONFIG NOTICES
        log('$yellow', 'Place input files in', '$red', this.INPUT_FOLDER);
        log('$yellow', 'Output files will be placed in', '$red', this.OUTPUT_FOLDER);
        console.log('\n');

        this.go(data); 
    }


    


    /**
     * Depends on oldPrompt being asked in go(); 
     * */

    getNewSheet() {
        if (this.oldPrompt == 0) {
            return 1;
        }
        else {
            return 0
        }
    }
   
    addAuditLegend() {
        let changesMade = []; 
        this.output.wb; 
        this.output.wb.addSheet('Audit Legend');
       
        //Append the legend itself. 
        for (let c of this.changes) {
            if (changesMade.indexOf(c.t) == -1) {
                changesMade.push(c.t); 
                let address = `A${changesMade.length}`;
                this.output.wb.sheets()[1].cell(address).value(this.auditLegend[c.t]); 
                this.output.wb.sheets()[1].cell(address).style('fill', this.errorColors[c.t]); 
                this.output.wb.sheets()[1].cell(address).style('wrapText', true); 
                this.output.wb.sheets()[1].cell(address).style('horizontalAlignment', 'center'); 
                this.output.wb.sheets()[1].cell(address).style('verticalAlignment', 'center'); 
                this.output.wb.sheets()[1].cell(address).column().width(25); 
            }
            
        }

        //TODO:  Automate this somewhat... maybe.  

        //Two cells down from the last used cell in the sheet.  
        let relAddress = this.output.wb.sheets()[1].usedRange().endCell().relativeCell(2, 0);
        let originalRel = this.output.wb.sheets()[1].usedRange().endCell().relativeCell(2, 0).address();
        relAddress.value("DETECTED CELLS:"); 

        relAddress = this.output.wb.sheets()[1].usedRange().endCell().relativeCell(1, 0);
        let startAddress = relAddress; 
        relAddress.value("CELL");
        relAddress = relAddress.relativeCell(0, 1);
        relAddress.value("ERROR");
        relAddress = relAddress.relativeCell(0, 1);
        relAddress.value("OLD VALUE");
        relAddress = relAddress.relativeCell(0, 1);
        relAddress.value("CURRENT VALUE");

        //Jump back to the original relative cell plus one more row:
        relAddress = this.output.wb.sheets()[1].usedRange().endCell().relativeCell(0, -3);

        //Append a set of data about the changes.
        for (let c of this.changes) {
            let cIndex = this.changes.indexOf(c) + 1;
            relAddress = relAddress.relativeCell(1, 0);
           
            for (let a of Object.keys(c)) {
                let aIndex = Object.keys(c).indexOf(a); 
              
                relAddress.relativeCell(0, aIndex).value(c[a]); 

                if (a == 't') {
                    relAddress.relativeCell(0, aIndex).style('fill', this.errorColors[c[a]]); 
                }

                if (a == 'o' || a == 'n') {
                    relAddress.relativeCell(0, aIndex).column().width(25); 
                    relAddress.relativeCell(0, aIndex).style('horizontalAlignment','left'); 
                }
            }
            
        }


    }
}
//cLog(`$red`, 2, 3, '$blue', 4, 5);


async function go() {
    let b = new BillCompare(['./input/old.xlsx', './input/new.xlsx']); 
}
go(); 