﻿'use strict';
const log = require('./colorlog.js');
const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Awaits user input in the console, and recurs if data constraints aren't met.  
 * */

class Questions {
    //Expects an integer return.  Optional range sets limits on return.  
    int(q, range) {
        q = q + " : "; 
        var self = this;
        return new Promise(function (resolve, reject) {
            rl.question(q, (a) => {
                let sanitize = a.match(/\d/);
                if (sanitize == null) {
                    log('$red',`Please provide an integer!`);
                    resolve(self.int(q, range));
                }
                else {
                    if (typeof range != 'undefined' && parseInt(a) > range) {
                        log('$red',`Number provided is outside of the possible range!`);
                        resolve(this.int(q, range));
                    }
                    resolve(parseInt(a));
                }
            });
        });
    }

    //Expects a string return.  
    str(q) {
        var self = this;
        q = q + ' : '
        return new Promise(function (resolve, reject) {
            rl.question(q, (a) => {
                let sanitize = a.match(/\D/);
                if (sanitize == null) {
                    log('$red',`Please provide a valid string input!`);
                    resolve(self.str(q));
                }
                else {
                    resolve(a);
                }
            });
        });
    }

    /**
      * Simple Y/N Prompt.
      * Use this instead of parsing strings for y/n questions.  
      * @param {string} q 
      */  
    boolean(q) {
        var self = this;
        return new Promise(function (resolve, reject) {
            q = q + ` Y/N: `
            rl.question(q, (a) => {
                a = a.toLowerCase(); 
                if (a != "y" && a != "n" && a != "yes" && a != "no") {
                    log('$red','Please respond either yes or no!');
                    resolve(self.boolean(q));
                }
                else {
                    let r;
                    if (a == "y" || a == "yes") {
                        r = true;
                    }
                    else {
                        r = false; 
                    }
                    resolve(r);
                }
            });
        });
    }
}

let q = new Questions(); 
module.exports = { int: q.int, str: q.str, boolean: q.boolean };